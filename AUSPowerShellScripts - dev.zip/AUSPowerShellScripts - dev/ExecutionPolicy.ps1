# Check Execution Policy
Get-ExecutionPolicy -list



##############             Changing Execution Policy Temporarily
# Instead of changing the execution policy permanently you could set a different policy 
# for a single PowerShell session. This is done using the ExecutionPolicy parameter of powershell.exe
# Open a command prompt or PowerShell and run the command:

# powershell.exe -executionpolicy -bypass -file C:\Users\aadmin\Documents\AUSCheckTLS.ps1


##############             Unblocking a File that was downloaded
# When the execution policy is RemoteSigned, the files that are downloaded from the internet 
# (or from emails) are blocked to protect your running unsafe scripts. If you trust the contents 
# of the script are safe then you can unblock it to run on your session using the Unblock-File cmdlet


# Unblock-File -Path $PSScriptRoot\'ExecutionPolicy.ps1'  # unblock single file

# write-output $PSScriptRoot 
# $allFiles = Get-ChildItem $PSScriptRoot -Recurse 
# write-host $allFiles
# $allFiles | Unblock-File


##############          Changing Execution Policy Permanently
# The easiest but unsecure method of getting rid of this error message is to 
# change the ExecutionPolicy using the SetExecutionPolicy cmdlet. The following 
# command sets the execution policy to unrestricted.

# Set-ExecutionPolicy unrestricted


