﻿
# PowerShell 3+ $PSScriptRoot is an automatic variable set to the current file's/module's directory

. "$PSScriptRoot\AUSLib.ps1"


#############################  update web.config Connection String  ######################
    # Import-Module sqlserver 


    $Server = 'BPW33Z2'
    $DBName = 'eCareTEST2'
    $User = 'ADVANCED'
    $Pwd = 'PATSINCOMMAND'

        # CIS  CIS  CIS  CIS  CIS DB info
        $CIS_Server = 'BPW33Z2'
        $CIS_DBName = 'UC2018v3'
        $CIS_User = 'ADVANCED'
        $CIS_Pwd = 'PATSINCOMMAND'
        $WEBSERVICEURL = 'http://pe3.local/aws_director/Director.asmx'
        $PortalAlias = 'ecaretest2.ci.richland.wa.us'

# Install-Module sqlserver

# check existing 
$query = 'select CISConnectionString, WEBSERVICEURL from eCAReManager'
$query = "SELECT name FROM SYSOBJECTS WHERE xtype = 'U' order by name"
  
# $results = ''
$results = Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd | select -expand name

# write-host $results + 'sssss'

foreach ($result in $results) {
    write-host $result + 'sssss'
}




