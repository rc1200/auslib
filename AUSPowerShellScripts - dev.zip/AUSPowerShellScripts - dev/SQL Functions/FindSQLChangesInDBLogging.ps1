﻿# scroll to the bottom to run the functions and variables

function enableLogging {
    $query = "EXEC sys.sp_cdc_enable_db"
    Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd
    write-host '---------------------  DONE enableLogging ----------------------'
}

function disableLogging {
    $query = "EXEC sys.sp_cdc_disable_db"
    Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd
    write-host '---------------------  DONE disableLogging ----------------------'
}


function enableTableLogging {

    $query = "SELECT name FROM SYSOBJECTS WHERE xtype = 'U' order by name"
    $allTables = Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd -ErrorAction Ignore | select -expand name
    
    foreach ($table in $allTables) {
    
        $query = "EXEC sys.sp_cdc_enable_table
            @source_schema = N'{0}'
          , @source_name = N'{1}'
          , @role_name = NULL  
          , @captured_column_list = NULL
          , @supports_net_changes = 1
        GO" -f $schema, $table
    
        write-host $query 
        Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd 
    }
    write-host '---------------------  DONE enableTableLogging ----------------------'
}


function disableTableLogging {

    $query = "SELECT name FROM SYSOBJECTS WHERE xtype = 'U' order by name"
    $allTables = Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd | select -expand name
    
    foreach ($table in $allTables) {
    
        $query = "EXEC sys.sp_cdc_disable_table 
        @source_schema = N'{0}'
      , @source_name = N'{1}'  
      , @capture_instance = N'{0}_{1}'" -f $schema, $table
    
      write-host $query 
        # Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd 
    }
    write-host '---------------------  DONE  disableTableLogging ----------------------'
}


function checkChanges {

    $query = "SELECT name FROM SYSOBJECTS WHERE xtype = 'U' order by name"
    $allTables = Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd | select -expand name
    
    write-host '---------------------  getting changes to DB results  ----------------------'  "`n"

    foreach ($table in $allTables) {
    
        $query = "select * from cdc.{0}_{1}_CT" -f $schema, $table
        # write-host $query 

        $result = Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd -ErrorAction Ignore
        if ($result){
            write-host $query 
        }


    }
    write-host '---------------------  DONE checkChanges ----------------------'
}

# queries to run to see results example


# 1 = delete
# 2 = insert
# 3 = update (old values)
# Column data has row values before executing the update statement.
# 4 = update (new values)
# Column data has row values after executing the update statement.

#EXEC sys.sp_cdc_enable_db
#EXEC sys.sp_cdc_disable_db
# SELECT * FROM cdc.change_tables
# EXEC sys.sp_cdc_help_change_data_capture 
# select * from cdc.dbo_Users_CT




# Make sure SQL Server Agent is enabled
# see https://www.youtube.com/watch?v=IJbAhfFRHdA for reference

#############################  Connection String  ######################
    # Import-Module sqlserver 


    $Server = 'BPW33Z2'
    $DBName = 'UC2019_V4'
    $User = 'sa'  # Need to have sysadmin Server Role
    $Pwd = 'a'
 #Dont forget to change this as the CIS DB use schema ADVANCED
    $schema = "ADVANCED" # dbo or ADVANCED

# Install-Module sqlserver

# enableLogging
# enableTableLogging

# run this (ensure you comment the top 2) to get the changes
# checkChanges

# disableTableLogging
# disableLogging

