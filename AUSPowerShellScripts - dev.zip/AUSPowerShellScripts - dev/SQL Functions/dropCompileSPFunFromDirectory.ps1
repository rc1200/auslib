﻿
# PowerShell 3+ $PSScriptRoot is an automatic variable set to the current file's/module's directory

write-host 'current directory is ' $PSScriptRoot
$prevFolder = Split-Path -Path $PSScriptRoot -Parent
Write-Host 'Previous directory is ' $prevFolder
. "$prevFolder\AUSLib.ps1"



#############################  drop SP then run the SPs files in the folder based on the regex pattern  ######################

# Install-Module sqlserver
# After the module has installed, the module commands including the Invoke-sqlcmd should be readily available.
# You can check the same using Get-Command -ModuleName sqlserver.
# If this module is not readily available, you can 
# Import-Module sqlserver 


$sourceDir = 'C:\Users\rc91124\OneDrive - harriscomputer\Documents\Ron\Tickets\50132\WebServices_03.03.03.02\WebServices_03.03.03.02\Stored Procedures CISV3\SQL'
$filePattern = '.*\.sql$'
# Needed to connect to correct DB and Table
$ServerName = 'BPW33Z2'
$DatabaseName = 'UC2018v3'
$userName = 'sa'
$password = 'a'



#############################  create drop script and SQLCMD mode query to run multiple scripts  ######################
# createDropAndSQLCMDQuery $sourceDir $filePattern

# NOTE: assumes that the name of the SP is the same sname as the File, ie. PendingPayments.sql and CREATE PROCEDURE PendingPayments 
# ... if PendingPayment no "S" then it will give error
dropCompileSPFunFromDirectory $sourceDir $filePattern $ServerName $DatabaseName $userName $password

