
##############################     Backup DB to specific destination    ##############################

# Backup-SqlDatabase -ServerInstance ["Put Name of Instance"] -Database ["DB name"] [ -Credential (Get-Credential advanced)] -BackupFile ["Destination .. ensure you have write permissions"]




# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "ADVANCED_API2" -BackupFile "C:\test\backups\ADVANCED_API2.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "AdvancedPaymentEngine" -BackupFile "C:\test\backups\AdvancedPaymentEngine.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "AdvancedPaymentEngineV3cis3" -BackupFile "C:\test\backups\AdvancedPaymentEngineV3cis3.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "AdvancedPaymentEngineV3Link" -BackupFile "C:\test\backups\AdvancedPaymentEngineV3Link.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "CIS4_V3Link" -BackupFile "C:\test\backups\CIS4_V3Link.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "eCareTest2" -BackupFile "C:\test\backups\eCareTest2.bak" -CompressionOption On

# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "InfinityLink" -BackupFile "C:\test\backups\InfinityLink.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "LinkV3" -BackupFile "C:\test\backups\LinkV3.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "LinkV3Play" -BackupFile "C:\test\backups\LinkV3Play.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "LinkV418" -BackupFile "C:\test\backups\LinkV418.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "linkv4xx" -BackupFile "C:\test\backups\linkv4xx.bak" -CompressionOption On

# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "Mobile20API" -BackupFile "C:\test\backups\Mobile20API.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "Mobile20Client" -BackupFile "C:\test\backups\Mobile20Client.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "Mobile20Dispatch" -BackupFile "C:\test\backups\Mobile20Dispatch.bak" -CompressionOption On

# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "MobileField" -BackupFile "C:\test\backups\MobileField.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "MobilePAManager" -BackupFile "C:\test\backups\MobilePAManager.bak" -CompressionOption On

# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "MobileUpgradeDispatch" -BackupFile "C:\test\backups\MobileUpgradeDispatch.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "MobileUpgradeField" -BackupFile "C:\test\backups\MobileUpgradeField.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "MobileUpgradePAManager" -BackupFile "C:\test\backups\MobileUpgradePAManager.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "MobileUpgradeWS" -BackupFile "C:\test\backups\MobileUpgradeWS.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "MobileWS" -BackupFile "C:\test\backups\MobileWS.bak" -CompressionOption On

# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "PAMANAGER_USERS" -BackupFile "C:\test\backups\PAMANAGER_USERS.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "PaymentQueue" -BackupFile "C:\test\backups\PaymentQueue.bak" -CompressionOption On

# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "UC2018v3" -BackupFile "C:\test\backups\UC2018v3.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "UC2019_V4" -BackupFile "C:\test\backups\UC2019_V4.bak" -CompressionOption On



################################    Restore DB to specific destination   ############################


function RestoreDB {

    param ([string] $ServerInstance, [string] $newDBName, [string] $backupFilePath, [string] $sqlDataPath,
        [Parameter(Mandatory=$false)] [string] $Username, [Parameter(Mandatory=$false)] [string] $Password )

    #, [string] $dataLogicalName, [string] $logLogicalName)
    # get Logical names for the MDF and LOG files so you can transfer to new file

    [string] $dbCommand = "RESTORE FILELISTONLY FROM DISK='$backupFilePath'"
    write-host $dbCommand

    $results = Invoke-Sqlcmd -Query $dbCommand | select -expand LogicalName

    write-host $results[0] ':0 is data'
    write-host $results[1] ':1 is log'
    $LogicalNameData = $results[0] 
    $LogicalNameLog  = $results[1] 

    # Perform the restore to new DB
    [string] $dbCommand = "RESTORE DATABASE [$newDBName] " +   
                          "FROM    DISK = N'$backupFilePath' " +
                          "WITH    FILE = 1, " +
                          "MOVE N'$LogicalNameData' " +
                          "TO N'$sqlDataPath\$newDBName.mdf', " +
                          "MOVE N'$LogicalNameLog' " +
                          "TO N'$sqlDataPath\$newDBName.ldf', " +
                          "NOUNLOAD, STATS = 10"   
   

    write-host $dbCommand

    if($Username -eq $null) {
        Invoke-Sqlcmd -ServerInstance $ServerInstance -Query $dbCommand
    }
    else {
        Invoke-Sqlcmd -ServerInstance $ServerInstance -Query $dbCommand -Username $Username -Password $Password    
    }

    write-host '********************   backup complete   *******************'

}


# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "UC2019_V4" -BackupFile "C:\test\backups\UC2019_V4-2020-05-15.bak" -CompressionOption On
# Backup-SqlDatabase -ServerInstance "BPW33Z2" -Database "LinkV3Play" -BackupFile "C:\test\backups\LinkV3PlayAfterTelerik.bak" -CompressionOption On

$ServerInstance = "BPW33Z2" 
$newDBName                      ='eCarePROD'
$backupFilePath ="C:\backup\LinkV3\RichlandProd3.1.x\eCarePROD.bak"
$sqlDataPath ='C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA' #Destination of new .mdf and .ldf files N.B. will be same as New DB Name
$Username = 'sa'
$Password = 'a'

# $sqlDataPath ='C:\test\DATA' #Destination of new .mdf and .ldf files N.B. will be same as New DB Name


# sp_change_users_login 'Auto_Fix', 'Advanced'
# RestoreDB $ServerInstance $newDBName $backupFilePath $sqlDataPath 
RestoreDB $ServerInstance $newDBName $backupFilePath $sqlDataPath $Username $Password



