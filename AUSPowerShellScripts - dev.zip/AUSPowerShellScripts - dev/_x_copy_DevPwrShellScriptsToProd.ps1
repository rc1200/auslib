. "$PSScriptRoot\AUSLib.ps1"


deleteFilesOrFoldersRecurseRegex 'C:\powershell\AUSPowerShellScripts' '.*'
deleteFilesRegex 'C:\powershell' 'AUSPowerShellScripts.zip'
copyFolderYesOverwriteKeepLaterDateFileOnly 'C:\powershell\AUSPowerShellScripts' 'C:\powershell\AUSPowerShellScripts - dev'
deleteFilesRegex 'C:\powershell\AUSPowerShellScripts' '(_x_copy_|test).*\.ps1'


deleteFilesOrFoldersRecurseRegex 'C:\github\AUSPowerShellScripts' '.*'
copyFolderYesOverwriteKeepLaterDateFileOnly 'C:\github\AUSPowerShellScripts' 'C:\powershell\AUSPowerShellScripts'