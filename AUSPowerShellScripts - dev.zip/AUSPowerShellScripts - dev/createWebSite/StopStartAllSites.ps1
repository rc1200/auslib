
# Import-Module WebAdministration
Get-ChildItem -Path IIS:\Sites | foreach { Stop-WebSite $_.Name; }
Get-ChildItem -Path IIS:\Sites | select Name

Get-ChildItem -Path IIS:\AppPools  | foreach { Stop-WebAppPool -Name $_.Name; }
Get-ChildItem IIS:\AppPools | select Name


Start-WebAppPool -Name "DefaultAppPool"
Start-WebAppPool -Name "PaymentEngineV3Richland"
Start-WebAppPool -Name "Lnk3RchLnd_v3.2.10"
Start-WebAppPool -Name "paymentUI"

Start-WebSite -Name "Default Web Site"
Start-WebSite -Name "PaymentEngineV3Richland"
Start-WebSite -Name "Lnk3RchLnd_v3.2.10_retry"
Start-WebSite -Name "paymentUI"




# Get-ChildItem -Path IIS:\AppPools  | foreach { Start-WebAppPool -Name $_.Name; }
# Get-ChildItem -Path IIS:\Sites | foreach { Start-WebSite $_.Name; }

