
#################################################################################



# READ me if you get errors seen below

# if you get New-Item : Cannot find drive. A drive with the name 'IIS' does not exist.


# run the following then run Get-PSDrive then you should see IIS
        # Remove-Module WebAdministration
        # Import-Module WebAdministration
        # Get-PSDrive # after running you should see IIS

        

#################################################################################


function updateWebsite {

    param(
        [Parameter(Mandatory)]
        [string]$currentSiteName,
        # Optional 
        [Parameter(Mandatory=$false)]
        [string]$currentSubSiteName,
        [Parameter(Mandatory=$false)]
        [string]$NewSiteName,
        [Parameter(Mandatory=$false)]
        [string]$NewSiteFolderPath,
        [Parameter(Mandatory=$false)]
        [string]$NewSiteHostName,
        [Parameter(Mandatory=$false)]
        [string]$NewportNumber=80,
        [Parameter(Mandatory=$false)]
        [string]$NewSiteAppPool,
        [Parameter(Mandatory=$false)]
        [string]$NewSubSiteName,
        [Parameter(Mandatory=$false)]
        [string]$managedPipelineMode,
        [Parameter(Mandatory=$false)]
        [string]$managedRuntimeVersion,
        [Parameter(Mandatory=$false)]
        [string]$ApplicationPoolIdentity,
        [Parameter(Mandatory=$false)]
        [string]$enable32BitAppOnWin64

    )
        

    if($NewSubSiteName -and $currentSubSiteName){
        Rename-Item IIS:\Sites\$currentSiteName\$currentSubSiteName $NewSubSiteName 
        $currentSubSiteName = $NewSubSiteName
    }
        
    if($NewSiteName){
        Rename-Item IIS:\Sites\$currentSiteName $NewSiteName 
        $currentSiteName = $NewSiteName
    }

    if($NewSiteFolderPath){
        if (Test-Path $NewSiteFolderPath) {   
            Set-ItemProperty IIS:\Sites\$currentSiteName\$currentSubSiteName -name physicalPath -value $NewSiteFolderPath
        }
    }
    if($NewSiteHostName){
        Set-ItemProperty IIS:\Sites\$currentSiteName\ -name bindings -value @{protocol="http";bindingInformation=":"+ $NewportNumber + ":" +$NewSiteHostName}
    }

    # assume apppool is the same as site name    
    if($managedPipelineMode) {Set-ItemProperty IIS:\AppPools\$currentSiteName1 -name managedPipelineMode -value $managedPipelineMode}
    if($managedRuntimeVersion) {Set-ItemProperty IIS:\AppPools\$currentSiteName1 -name managedRuntimeVersion -value $managedRuntimeVersion}
    if($enable32BitAppOnWin64) {Set-ItemProperty IIS:\AppPools\$currentSiteName1 -name enable32BitAppOnWin64 -value $enable32BitAppOnWin64}
    if($ApplicationPoolIdentity) {Set-ItemProperty IIS:\AppPools\$currentSiteName1 -name processModel.identityType -value $ApplicationPoolIdentity}


    if($NewSiteAppPool){
        if(!(Test-Path IIS:\AppPools\$NewSiteAppPool)) {
            New-Item IIS:\AppPools\$NewSiteAppPool
        }
        Set-ItemProperty IIS:\Sites\$currentSiteName\$currentSubSiteName -name applicationPool -value $NewSiteAppPool
    }


}





Import-Module WebAdministration
$currentSiteName1 = "z1"   # Main IIS Site Name, Mandatory

# OPTIONAL -------- if don't use then keep existing values

    $NewSiteName1 =  'z1'                     # New IIS Site Name
    $NewSiteHostName1 =    'www.abc.local'         # ie. link.com -- only for Main site

        # seetings only for SubSite
        $currentSubSiteName1 = ''
        $NewSubSiteName1 = ''

$managedPipelineMode1 = 'Integrated' # Integrated -- don't use anymore'Classic'
$managedRuntimeVersion1 = 'v4.0'  #''v4.0' or v2.0
$ApplicationPoolIdentity1 = 'NetworkService'  # ApplicationPoolIdentity, NetworkService, LocalSystem
$enable32BitAppOnWin641 = 'True'     # False True

# seetings for Main or Subsite, note: if subsite is set then this will update subsite
$NewSiteFolderPath1 =  'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileRaj'            # Website Folder or @false 
$NewSiteAppPool1 = 'ronpool2'                  # Application Pool Name or @false 
# $NewportNumber = 80   # already defaulted to 80

# N.B. current only use port 80 and only http for bindings, no HTTPS. Change manually if needed


# Execute
# updateWebsite -currentSiteName $currentSiteName1 -NewSiteFolderPath $NewSiteFolderPath1 `
#                 -NewSiteHostName $NewSiteHostName1 -NewSiteAppPool $NewSiteAppPool1 `
#                 -currentSubSiteName $currentSubSiteName1 -NewSubSiteName $NewSubSiteName1 `
#                 -NewSiteName $NewSiteName1 -managedPipelineMode $managedPipelineMode1 `
#                 -managedRuntimeVersion $managedRuntimeVersion1  `
#                 -ApplicationPoolIdentity $ApplicationPoolIdentity1 `
#                 -enable32BitAppOnWin64 $enable32BitAppOnWin641 




# $currentSiteName1 = "z1"   # Main IIS Site Name, Mandatory
# $NewSiteHostName1 =    'www.abc.local'         # ie. link.com -- only for Main site
# $NewSiteFolderPath1 =  'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileRaj'    
# $managedPipelineMode1 = 'Integrated' # Integrated -- don't use anymore'Classic'
# $managedRuntimeVersion1 = 'v4.0'  #''v4.0' or v2.0
# $ApplicationPoolIdentity1 = 'ApplicationPoolIdentity'  # ApplicationPoolIdentity, NetworkService, LocalSystem
# $enable32BitAppOnWin641 = 'True'     # False True


# updateWebsite -currentSiteName $currentSiteName1 -NewSiteHostName $NewSiteHostName1 -NewSiteFolderPath $NewSiteFolderPath1 `
# -managedPipelineMode $managedPipelineMode1 -managedRuntimeVersion $managedRuntimeVersion1 `
# -ApplicationPoolIdentity $ApplicationPoolIdentity1 -enable32BitAppOnWin64 $enable32BitAppOnWin641 


#######################################################
$MobileCISFolderPath        = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileRaj\WebServices\MobileCIS\Advanced.MobileWebService.MobileCIS'
$MobilePAManagerFolderPath  = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileRaj\WebServices\PA_Manager'
$MobileDirectorFolderPath   = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileRaj\WebServices\MobileDirector\Advanced.MobileWebService.MobileDirector'
$MobileWSFolderPath         = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileRaj\WebServices\InfinityMobile\Advanced.MobileWebService.InfinityMobile'
$MobileDispatchFolderPath   = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileRaj\Dispatch'
$MobileClientFolderPath     = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileRaj\Field'


$currentSiteName1 = "MobileCIS"   # Main IIS Site Name, Mandatory
updateWebsite -currentSiteName $currentSiteName1  -NewSiteFolderPath $MobileCISFolderPath 

$currentSiteName1 = "MobilePAManager"   # Main IIS Site Name, Mandatory
updateWebsite -currentSiteName $currentSiteName1  -NewSiteFolderPath $MobilePAManagerFolderPath 

$currentSiteName1 = "MobileDirector"   # Main IIS Site Name, Mandatory
updateWebsite -currentSiteName $currentSiteName1  -NewSiteFolderPath $MobileDirectorFolderPath 

$currentSiteName1 = "MobileWS"   # Main IIS Site Name, Mandatory
updateWebsite -currentSiteName $currentSiteName1  -NewSiteFolderPath $MobileWSFolderPath 

$currentSiteName1 = "MobileDispatch"   # Main IIS Site Name, Mandatory
updateWebsite -currentSiteName $currentSiteName1  -NewSiteFolderPath $MobileDispatchFolderPath 

$currentSiteName1 = "MobileClient"   # Main IIS Site Name, Mandatory
updateWebsite -currentSiteName $currentSiteName1  -NewSiteFolderPath $MobileClientFolderPath 


Write-Host 'website Update complete'