. "$PSScriptRoot\AUSLib.ps1"

$existingFolder = 'C:\test\f1'
$FolderToCopy = 'C:\test\f2'

copyFolderYesOverwriteKeepLaterDateFileOnly $existingFolder $FolderToCopy