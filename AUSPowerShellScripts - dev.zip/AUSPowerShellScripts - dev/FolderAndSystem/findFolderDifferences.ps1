write-host 'current directory is ' $PSScriptRoot
$prevFolder = Split-Path -Path $PSScriptRoot -Parent
Write-Host 'Previous directory is ' $prevFolder
. "$prevFolder\AUSLib.ps1"

$OlderFolder = 'C:\inetpub\wwwroot\v3\InfinityLinkTEST2RiclndV03.02.10_retry - Copy' 
$NewerFolder = 'C:\inetpub\wwwroot\v3\InfinityLinkTEST2RiclndV03.02.10_retry'

listNewerFilesCompareFolders $OlderFolder $NewerFolder