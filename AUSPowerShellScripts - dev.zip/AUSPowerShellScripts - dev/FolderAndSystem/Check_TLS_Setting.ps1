Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' # should have entry SchUseStrongCrypto with value of 1   
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' # should have entry SchUseStrongCrypto with value of 1   
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' # Enabled should be 0, DisabledByDefault  1
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' # Enabled should be 0, DisabledByDefault  1
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' # Enabled should be 0, DisabledByDefault  1
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' # Enabled should be 0, DisabledByDefault  1
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' # Enabled should be 0
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' # Enabled should be 0
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' # Enabled Optional 0/1
Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' # Enabled Optional 0/1
Get-Item -Path Registry::'HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' # Enabled should be 1
Get-Item -Path Registry::'HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' # Enabled should be 1



# Hive: HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\.NETFramework
# Name                           Property                                                                                                                                                                                              
# ----                           --------                                                                                                                                                                                              
# v4.0.30319                     AspNetEnforceViewStateMac : 1                                                                                                                                                                         
#                                SystemDefaultTlsVersions  : 1                                                                                                                                                                         
#                                SchUseStrongCrypto        : 1                                                                                                                                                                         
#     Hive: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0
# Name                           Property                                                                                                                                                                                              
# ----                           --------                                                                                                                                                                                              
# Client                         Enabled           : 0                                                                                                                                                                                 
#                                DisabledByDefault : 1                                                                                                                                                                                 
# Server                         Enabled           : 0                                                                                                                                                                                 
#                                DisabledByDefault : 1                                                                                                                                                                                 
#     Hive: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0
# Name                           Property                                                                                                                                                                                              
# ----                           --------                                                                                                                                                                                              
# Client                         Enabled           : 0                                                                                                                                                                                 
#                                DisabledByDefault : 1                                                                                                                                                                                 
# Server                         Enabled           : 0                                                                                                                                                                                 
#     Hive: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0
# Name                           Property                                                                                                                                                                                              
# ----                           --------                                                                                                                                                                                              
# Client                         Enabled           : 0                                                                                                                                                                                 
#                                DisabledByDefault : 1                                                                                                                                                                                 
# Server                         Enabled           : 0                                                                                                                                                                                 
#                                DisabledByDefault : 1                                                                                                                                                                                 
#     Hive: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1
# Name                           Property                                                                                                                                                                                              
# ----                           --------                                                                                                                                                                                              
# Client                         Enabled           : 0                                                                                                                                                                                 
#                                DisabledByDefault : 1                                                                                                                                                                                 
# Server                         Enabled           : 0                                                                                                                                                                                 
#                                DisabledByDefault : 1                                                                                                                                                                                 
#     Hive: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2
# Name                           Property                                                                                                                                                                                              
# ----                           --------                                                                                                                                                                                              
# Client                         Enabled           : 4294967295                                                                                                                                                                        
#                                DisabledByDefault : 0                                                                                                                                                                                 
# Server                         Enabled           : 4294967295                                                                                                                                                                        
#                                DisabledByDefault : 0      



# .Net Framework
# https://docs.microsoft.com/en-us/dotnet/framework/migration-guide/how-to-determine-which-versions-are-installed
# Get-Item -Path Registry::'HKLM\Software\Microsoft\NET Framework Setup\NDP\v3.0\Setup' # InstallSuccess REG_DWORD equals 1
# Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v3.5' # Install REG_DWORD equals 1
# Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP' 
# Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client' # Install REG_DWORD equals 1
# Get-Item -Path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' # Install REG_DWORD equals 1

Get-DotNetFrameworkVersion

function Get-DotNetFrameworkVersion {

    <#
        Script Name	: Get-NetFrameworkVersion.ps1
        Description	: This script reports the various .NET Framework versions installed on the local or a remote computer.
        Author		: Martin Schvartzman
        Reference   : https://msdn.microsoft.com/en-us/library/hh925568
    #>
    param(
        [string]$ComputerName = $env:COMPUTERNAME
    )

    $dotNetRegistry  = 'SOFTWARE\Microsoft\NET Framework Setup\NDP'
    $dotNet4Registry = 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    $dotNet4Builds = @{
        '30319'  = @{ Version = [System.Version]'4.0'                                                     }
        '378389' = @{ Version = [System.Version]'4.5'                                                     }
        '378675' = @{ Version = [System.Version]'4.5.1'   ; Comment = '(8.1/2012R2)'                      }
        '378758' = @{ Version = [System.Version]'4.5.1'   ; Comment = '(8/7 SP1/Vista SP2)'               }
        '379893' = @{ Version = [System.Version]'4.5.2'                                                   }
        '380042' = @{ Version = [System.Version]'4.5'     ; Comment = 'and later with KB3168275 rollup'   }
        '393295' = @{ Version = [System.Version]'4.6'     ; Comment = '(Windows 10)'                      }
        '393297' = @{ Version = [System.Version]'4.6'     ; Comment = '(NON Windows 10)'                  }
        '394254' = @{ Version = [System.Version]'4.6.1'   ; Comment = '(Windows 10)'                      }
        '394271' = @{ Version = [System.Version]'4.6.1'   ; Comment = '(NON Windows 10)'                  }
        '394802' = @{ Version = [System.Version]'4.6.2'   ; Comment = '(Windows 10 Anniversary Update)'   }
        '394806' = @{ Version = [System.Version]'4.6.2'   ; Comment = '(NON Windows 10)'                  }
        '460798' = @{ Version = [System.Version]'4.7'     ; Comment = '(Windows 10 Creators Update)'      }
        '460805' = @{ Version = [System.Version]'4.7'     ; Comment = '(NON Windows 10)'                  }
        '461308' = @{ Version = [System.Version]'4.7.1'   ; Comment = '(Windows 10 Fall Creators Update)' }
        '461310' = @{ Version = [System.Version]'4.7.1'   ; Comment = '(NON Windows 10)'                  }
        '461808' = @{ Version = [System.Version]'4.7.2'   ;                                               }
        '461814' = @{ Version = [System.Version]'4.7.2'   ;                                               }
        '528040' = @{ Version = [System.Version]'4.8'     ;                                               }
        '528049' = @{ Version = [System.Version]'4.8'     ;                                               }
        
    }

    foreach($computer in $ComputerName)
    {
        if($regKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $computer))
        {
            if ($netRegKey = $regKey.OpenSubKey("$dotNetRegistry"))
            {
                foreach ($versionKeyName in $netRegKey.GetSubKeyNames())
                {
                    if ($versionKeyName -match '^v[123]') {
                        $versionKey = $netRegKey.OpenSubKey($versionKeyName)
                        $version = [System.Version]($versionKey.GetValue('Version', ''))
                        New-Object -TypeName PSObject -Property ([ordered]@{
                                ComputerName = $computer
                                Build = $version.Build
                                Version = $version
                                Comment = ''
                        })
                    }
                }
            }

            if ($net4RegKey = $regKey.OpenSubKey("$dotNet4Registry"))
            {
                if(-not ($net4Release = $net4RegKey.GetValue('Release')))
                {
                    $net4Release = 30319
                }
                New-Object -TypeName PSObject -Property ([ordered]@{
                        ComputerName = $Computer
                        Build = $net4Release
                        Version = $dotNet4Builds["$net4Release"].Version
                        Comment = $dotNet4Builds["$net4Release"].Comment
                })
            }
        }
    }
}


