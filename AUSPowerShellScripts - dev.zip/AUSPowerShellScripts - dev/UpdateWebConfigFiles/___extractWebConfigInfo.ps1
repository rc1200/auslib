
# PowerShell 3+ $PSScriptRoot is an automatic variable set to the current file's/module's directory

# write-host 'current directory is ' $PSScriptRoot
# $prevFolder = Split-Path -Path $PSScriptRoot -Parent
# Write-Host 'Previous directory is ' $prevFolder
# . "$prevFolder\AUSLib.ps1"

# Get-DotNetFrameworkVersion
# $scriptName =$MyInvocation.MyCommand.Name 



# dot-source library script
# notice that you need to have a space 
# between the dot and the path of the script









function extractLinesInTextRegEx ($sourceDirRecurse, $filesToChangeRegExArray, $outputFile, $regExPatternCopyLineArray, $append_or_new) {
    <#
        Traverse through the $sourceDirRecurse and searches for specifc text in the files that match  $filesToChangeRegExArray
        In Each file, looks at each line to see if there is a matching $regExPatternCopyLineArray
        if match, store in $newfile then after going through all files, outputs results to $outputFile
    #>

    $newfile= @() # Stores the lines that match which will then be outputed to file
    
    # stores results of all files/folders in $sourceDirRecurse (-recurse) that match $filesToChangeRegExArray to  $fileToChange
    
    write-host 'gathering files... please wait'
    $fileToChange = dir -recurse -path $sourceDirRecurse | % { 
        Foreach ($filePattern in $filesToChangeRegExArray) {
            if ($_.Name -match $filePattern) {$_.FullName}
        }
    }

    write-host 'checking files for match... please wait'
    # Go through all files stored in  $fileToChange and looks for lines that match pattern $regExPatternCopyLineArray and store in $newfile
    foreach($file in $fileToChange){

        $newfile += $file + '  Gathering data for file *****************************************'
        $temp = Get-Content -Path $file 

        Foreach ($rPattern_x in $regExPatternCopyLineArray){
            Foreach ($line in $temp) {
                if ($line -match $rPattern_x) {
                $newfile += $line 
                }
            }
        }
    }

    # output results of matching lines to new file or append

    if ($append_or_new -ieq 'new'){ $newfile | Out-file $outputFile -width 400}
    ElseIf  ($append_or_new -ieq 'append'){ $newfile | Out-file $outputFile -Append -width 400}

}







####################################### extract text  #####################################

            $sourceDir = 'C:\CIS\test2\WebServices_03.03.03.02'
            $outputFile = $PSScriptRoot + '\extractedText_' + ($sourceDir |split-path -leaf) + '.txt' # Explictly put ful path
            $append_or_new = 'append' # new or append if you are going to append to file

$filesToChangeRegExArray =  @('^web.config$')
    # (?i)http(s)?(?-i) --> (?i) case-insensitive mode ON | (?-i) case-insensitive mode OFF | (s)? character "s" is optional
    # :. find patterns like http:, HTTP:, https:, HTTPs: even hTTpS:
$regExDBConnection = '(^.*Source=|^.*Server=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=)(.*?)(;Password=|;pwd=)(.*?)(;.*|".*)'
$regExURL = '(.*<add key=.*(?i)url(?-i)".*)|(.*target name="eventlog".*)'
$regExInvoiceCloud = '.*(<add key=")(ICIntegratorGUID|ICBillerGUID|ICWSKey).*'
$regExRest = '.*(<add key=")(RestApiBaseUrl|CisUserName|CisPassword).*'
$regExMachineKey = '.*<machineKey.*'

$regExPatternCopyLineArray = @($regExDBConnection, $regExURL, $regExInvoiceCloud, $regExRest, $regExMachineKey)

extractLinesInTextRegEx $sourceDir $filesToChangeRegExArray $outputFile $regExPatternCopyLineArray $append_or_new


