﻿# PowerShell 3+ $PSScriptRoot is an automatic variable set to the current file's/module's directory

write-host 'current directory is ' $PSScriptRoot
$prevFolder = Split-Path -Path $PSScriptRoot -Parent
Write-Host 'Previous directory is ' $prevFolder
. "$prevFolder\AUSLib.ps1"

Get-DotNetFrameworkVersion
$scriptName =$MyInvocation.MyCommand.Name 



# dot-source library script
# notice that you need to have a space 
# between the dot and the path of the script



####################################### extract text  #####################################

            $sourceDir = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobile20'
            $outputFile = $prevFolder + '\' + $scriptName + '_extractedTextOut.txt' # Explictly put ful path
            $append_or_new = 'append' # new or append if you are going to append to file

$filesToChangeRegExArray =  @('^web.config')
    # (?i)http(s)?(?-i) --> (?i) case-insensitive mode ON | (?-i) case-insensitive mode OFF | (s)? character "s" is optional
    # :. find patterns like http:, HTTP:, https:, HTTPs: even hTTpS:
$regExDBConnection = '(^.*Source=|^.*Server=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=)(.*?)(;Password=|;pwd=)(.*?)(;.*|".*)'
$regExURL = '(.*<add key=.*(?i)url(?-i)".*)|(.*target name="eventlog".*)'
$regExPatternCopyLineArray = @($regExDBConnection, $regExURL)

# extractLinesInTextRegEx $sourceDir $filesToChangeRegExArray $outputFile $regExPatternCopyLineArray $append_or_new




#############################  update web.config Connection String  ######################

# NEED to see how v20 config is as it may have changed and 1 less DB

$MobileCISFolderPath        = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileUpgrade\WebServices\MobileCIS\Advanced.MobileWebService.MobileCIS'
$MobilePAManagerFolderPath  = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileUpgrade\WebServices\PA_Manager'
$MobileDirectorFolderPath   = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileUpgrade\WebServices\MobileDirector\Advanced.MobileWebService.MobileDirector'
$MobileWSFolderPath         = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileUpgrade\WebServices\InfinityMobile\Advanced.MobileWebService.InfinityMobile'
$MobileDispatchFolderPath   = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileUpgrade\Dispatch'
$MobileClientFolderPath     = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobileUpgrade\Field'

$MobileDispatchDB = 'MobileUpgradeDispatch'
$MobileClientDB = 'MobileUpgradeField'
$MobileAPIDB = 'MobileUpgradeWS'
$PAMANAGER_USERS = 'MobileUpgradePAManager' # up to 3.2.19
    $isMobile_GT_3_2_19 = $tfalse # values are $false $true  if the version is > 3.2.19... 
    if ($isMobile_GT_3_2_19) {
        $PAMANAGER_USERS = $MobileAPIDB # in 3.2.19 this is combined in $MobileAPIDB
    }
$DBSErver = 'BPW33Z2'
$dbUser = 'ADVANCED'
$dbPassword = 'PATSINCOMMAND'

$MobileCISWSUrl = 'http://MobileUpgradeCIS.local.com/MobileCIS.asmx'
$InfinityMobileWSUrl = 'http://mobileUpgradeWS.local.com/AdvancedInfinityMobile.asmx'


#   ***************************** Infinity Mobile Dispatch  ***************************

    $sourceDirPath = $MobileDispatchFolderPath
    $singleFileToChange = 'web.config'
    $replaceFileName = Join-Path $sourceDirPath $singleFileToChange
    # $replaceFileName = 'c:\test\new.config'
    backUpFile $sourceDirPath $singleFileToChange

    #         ---------------  Connection String1   ----------------
    $regExConStringPattern1 = @('(.*SiteSqlServer.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;Provider=|".*?providerName=")(.*?)(;.*|".*)')
    $Server1 = $DBSErver  ;    $DBName1 = $MobileDispatchDB  ;  $User1 = $dbUser ; $Pwd1 = $dbPassword ; $provider1 = 'System.Data.SqlClient'
    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10$provider1`$12")
    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  

    #         ---------------  Connection String2 (No Provider)   ----------------
    $regExConStringPattern1 = @('(.*key="SiteSqlServer.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;.*|".*)')
    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10")
    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  





                    #   ***************************** Infinity Mobile Client  ***************************

                    $sourceDirPath = $MobileClientFolderPath 
                    $singleFileToChange = 'web.config'
                    $replaceFileName = Join-Path $sourceDirPath $singleFileToChange
                    # $replaceFileName = 'c:\test\new.config'
                    backUpFile $sourceDirPath $singleFileToChange

                    #         ---------------  Connection String1   ----------------
                    $regExConStringPattern1 = @('(.*SiteSqlServer.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;Provider=|".*?providerName=")(.*?)(;.*|".*)')
                    $Server1 = $DBSErver  ;    $DBName1 = $MobileClientDB  ;  $User1 = $dbUser ; $Pwd1 = $dbPassword ; $provider1 = 'System.Data.SqlClient'    
                    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10$provider1`$12")
                    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  

                    #         ---------------  Connection String2 (No Provider)   ----------------
                    $regExConStringPattern1 = @('(.*key="SiteSqlServer.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;.*|".*)')
                    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10")
                    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  


    #   ***************************** Infinity Mobile InfinityMobile/WS  ***************************

    $sourceDirPath = $MobileWSFolderPath
    $singleFileToChange = 'web.config'
    $replaceFileName = Join-Path $sourceDirPath $singleFileToChange
    # $replaceFileName = 'c:\test\new.config'
    backUpFile $sourceDirPath $singleFileToChange

    #         ---------------  Connection String1   ----------------
    $regExConStringPattern1 = @('(.*SqlConnectString.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;Provider=|".*?providerName=")(.*?)(;.*|".*)')
    $Server1 = $DBSErver  ;    $DBName1 = $MobileAPIDB  ;  $User1 = $dbUser ; $Pwd1 = $dbPassword ; $provider1 = 'SQLOLEDB.1'    
    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10$provider1`$12")
    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  

    #         ---------------  Connection String2 (No Provider)   ----------------
    $regExConStringPattern1 = @('(.*key="MobileConnectString.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;.*|".*)')
    $Server1 = $DBSErver  ;    $DBName1 = $MobileDispatchDB  ;  $User1 = $dbUser ; $Pwd1 = $dbPassword 
    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10")
    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  

    #         ---------------  Connection String3 (No Provider)   ----------------
    $regExConStringPattern1 = @('(.*key="MobileClientConnectString.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;.*|".*)')
    $Server1 = $DBSErver  ;    $DBName1 = $MobileClientDB  ;  $User1 = $dbUser ; $Pwd1 = $dbPassword 
    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10")
    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  



                    #   ***************************** Infinity Mobile MobileCIS  ***************************

                    $sourceDirPath = $MobileCISFolderPath
                    $singleFileToChange = 'web.config'
                    $replaceFileName = Join-Path $sourceDirPath $singleFileToChange
                    # $replaceFileName = 'c:\test\new.config'
                    backUpFile $sourceDirPath $singleFileToChange

                    #         ---------------  Connection String1   ----------------
                    $regExConStringPattern1 = @('(.*SqlConnectString.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;Provider=|".*?providerName=")(.*?)(;.*|".*)')
                    $Server1 = $DBSErver  ;    $DBName1 = $MobileAPIDB  ;  $User1 = $dbUser ; $Pwd1 = $dbPassword ; $provider1 = 'SQLOLEDB.1'    
                    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10$provider1`$12")
                    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  


    #   ***************************** Infinity Mobile MobileDirector  ***************************

    $sourceDirPath = $MobileDirectorFolderPath
    $singleFileToChange = 'web.config'
    $replaceFileName = Join-Path $sourceDirPath $singleFileToChange
    # $replaceFileName = 'c:\test\new.config'
    backUpFile $sourceDirPath $singleFileToChange

    #         ---------------  No Connection String, just URL to replace   ----------------
    $regExConStringPattern1 = @('(.*MobileCISWSUrl.*value=")(.*?)(".*)','(.*InfinityMobileWSUrl.*value=")(.*?)(".*)')
    # $MobileCISWSUrl = 'http://Mobile20CIS.local.com/MobileCIS.asmx'
    # $InfinityMobileWSUrl = 'http://mobile20WS.local.com/AdvancedInfinityMobile.asmx'
    $replaceConString =  @("`$1$MobileCISWSUrl`$3", "`$1$InfinityMobileWSUrl`$3")
    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  



                    #   ***************************** Infinity Mobile PA_Manager  ***************************

                    $sourceDirPath = $MobilePAManagerFolderPath
                    $singleFileToChange = 'web.config'
                    $replaceFileName = Join-Path $sourceDirPath $singleFileToChange
                    # $replaceFileName = 'c:\test\new.config'
                    backUpFile $sourceDirPath $singleFileToChange

                    #         ---------------  Connection String1   ----------------
                    $regExConStringPattern1 = @('(.*SQLSERVER_DB.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;Provider=|".*?providerName=")(.*?)(;.*|".*)')
                    $Server1 = $DBSErver  ;    $DBName1 = $MobileAPIDB  ;  $User1 = $dbUser ; $Pwd1 = $dbPassword ; $provider1 = 'System.Data.SqlClient'    
                    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10$provider1`$12")
                    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  

                    
                    #         ---------------  Connection String2   ----------------
                    $regExConStringPattern1 = @('(.*LocalSqlServer.*)(Server=|Source=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=|;.*User ID=)(.*?)(;Password=|;pwd=)(.*?)(;Provider=|".*?providerName=")(.*?)(;.*|".*)')
                    $Server1 = $DBSErver  ;    $DBName1 = $PAMANAGER_USERS  ;  $User1 = $dbUser ; $Pwd1 = $dbPassword ; $provider1 = 'System.Data.SqlClient'    
                    $replaceConString =  @("`$1`$2$Server1`$4$DBName1`$6$User1`$8$Pwd1`$10$provider1`$12")
                    replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $replaceFileName $regExConStringPattern1 $replaceConString  

Write-Host 'Config files updated'                    

#>


<#

# scripts to change the portal alias and other settings vs doing it manually


use MobileV2
select * from PortalAlias where portalid = 0
update PortalAlias set HTTPAlias = 'MobileDispatch.local.com' 
where portalid = 0 and PortalAliasID = 8

select WEBSERVICEURL from MobileManager
update MobileManager set WEBSERVICEURL = 'http://mobiledirector.local.com/MobileDirector.asmx' 

select * from HostSettings 
where SettingName in ('HostEmail','SMTPUsername', 'SMTPServer', 'SMTPAuthentication', 'HostURL')

update HostSettings set SettingValue = 'aaaaa@advancedutility.com'
where SettingName in ('HostEmail','SMTPUsername')

update HostSettings set SettingValue = 'http://mobiledispatch.local.com'
where SettingName in ('HostURL')

update HostSettings set SettingValue = 'mail.harriscomputer.com'
where SettingName in ('SMTPServer')

update HostSettings set SettingValue = 0
where SettingName in ('SMTPAuthentication')

update aspnet_Membership
set Email = 'rcalibuso@advancedutility.com', 
LoweredEmail = 'rcalibuso@advancedutility.com'

update Packages set email = 'rcalibuso@advancedutility.com'
where email like '%@%'

update Users set Email = 'rcalibuso@advancedutility.com'


----**************************************************************

use MobileV2Client
select * from PortalAlias where portalid = 0
update PortalAlias set HTTPAlias = 'MobileClient.local.com' 
where portalid = 0 and PortalAliasID = 7

select * from TabModuleSettings
where SettingName = 'txtDispatchsite'

update TabModuleSettings set SettingValue = 'http://mobiledispatch.local.com'
where SettingName = 'txtDispatchsite'

select * from TabModuleSettings
where SettingName = 'WSURL'

update TabModuleSettings set SettingValue = 'http://mobiledispatch.local.com/DesktopModules/Advanced.Mobile.Updater/MobileUpdater.asmx'
where SettingName = 'WSURL'

select * from MobileClientManager
where ItemName in ('WebServiceURL','ClientSiteURL') and PortalID = 0

update MobileClientManager set ItemValue = 'http://mobiledirector.local.com/MobileDirector.asmx'
where ItemName in ('WebServiceURL') and PortalID = 0

update MobileClientManager set ItemValue = 'http://mobileclient.local.com'
where ItemName in ('ClientSiteURL') and PortalID = 0

select * from HostSettings 
where SettingName in ('HostEmail','SMTPUsername', 'SMTPServer', 'SMTPAuthentication', 'HostURL')

update HostSettings set SettingValue = 'aaaa@advancedutility.com'
where SettingName in ('HostEmail','SMTPUsername')

update HostSettings set SettingValue = 'http://mobileclient.local'
where SettingName in ('HostURL')

update HostSettings set SettingValue = 'mail.harriscomputer.com'
where SettingName in ('SMTPServer')

update HostSettings set SettingValue = 0
where SettingName in ('SMTPAuthentication')

update aspnet_Membership
set Email = 'rcalibuso@advancedutility.com', 
LoweredEmail = 'rcalibuso@advancedutility.com'

update Packages set email = 'rcalibuso@advancedutility.com'
where email like '%@%'

update Users set Email = 'rcalibuso@advancedutility.com'


-------------------------*******************
use PAMANAGER_USERS

update aspnet_Membership
set Email = 'rcalibuso@advancedutility.com', 
LoweredEmail = 'rcalibuso@advancedutility.com'


--- go to the PA manager and chagne the connection string to CIS

#>
