
# PowerShell 3+ $PSScriptRoot is an automatic variable set to the current file's/module's directory

write-host 'current directory is ' $PSScriptRoot
$prevFolder = Split-Path -Path $PSScriptRoot -Parent
Write-Host 'Previous directory is ' $prevFolder
. "$prevFolder\AUSLib.ps1"

Get-DotNetFrameworkVersion
$scriptName =$MyInvocation.MyCommand.Name 



# dot-source library script
# notice that you need to have a space 
# between the dot and the path of the script



####################################### extract text  #####################################

            $sourceDir = 'C:\inetpub\wwwroot\v4\AdvancedPaymentEngine'
            $outputFile = $prevFolder + '\' + $scriptName + '_extractedTextOut.txt' # Explictly put ful path
            $append_or_new = 'append' # new or append if you are going to append to file

$filesToChangeRegExArray =  @('^web.config$')
    # (?i)http(s)?(?-i) --> (?i) case-insensitive mode ON | (?-i) case-insensitive mode OFF | (s)? character "s" is optional
    # :. find patterns like http:, HTTP:, https:, HTTPs: even hTTpS:
$regExDBConnection = '(^.*Source=|^.*Server=)(.*?)(;.*Catalog=|;.*Database=)(.*?)(;.*ID=|;.*uid=)(.*?)(;Password=|;pwd=)(.*?)(;.*|".*)'
$regExURL = '(.*<add key=.*(?i)url(?-i)".*)|(.*target name="eventlog".*)'
$machineKey = '.*machineKey validationKey="(.*?)".*decryptionKey="(.*?)".*'
$requireSSL = '.*(<\w).*(?i)requireSSL(?-i).*'

$regExPatternCopyLineArray = @($regExDBConnection, $regExURL, $machineKey, $requireSSL)

# extractLinesInTextRegEx $sourceDir $filesToChangeRegExArray $outputFile $regExPatternCopyLineArray $append_or_new




#############################  update web.config Files(s) ######################
# updates sourceDirPath, and if exists... update the Director, CIS and PG web config as well

        $sourceDirPath = 'C:\inetpub\wwwroot\v3\InfinityLinkTEST2RiclndV03.02.10'
        $singleFileToChange = 'web.config'

# variables for DB Connection String

        # LINK DB info
        $Server = 'BPW33Z2'
        $DBName = 'eCareTEST2'
        $User = 'ADVANCED'
        $Pwd = 'PATSINCOMMAND'
        # Optional
        $PortalURL = 'http://ecaretest2.ci.richland.wa.us' # URL for Link
        $paymentEngineUrl = 'http://pe3.local' # put WebService/Payment engine URL
                        $AWS_DIRECTOR_Alias = 'AWS_DIRECTOR'
                        $WebserviceUrl =  $paymentEngineUrl + '/' + $AWS_DIRECTOR_Alias + '/Director.asmx'   
                    
                #RestApiBaseUrl -- v4

        $regExPatternArray = @('(.*machineKey validationKey=)"(.*?)"(.*decryptionKey=)"(.*?)"(.*)')
        $validationKey = "7309AE9660803448B8FC30C9476B2661ECF9263C"
        $decryptionKey = '96974F916D18A8C37107B593078D55941F9C917DE095AC97'
        $replaceStringArray = @('$1"{0}"$3"{1}"$5' -f $validationKey,$decryptionKey)

<#            
updateStringsInFiles $sourceDirPath $singleFileToChange $Server $DBName $User $Pwd `
                        -PortalURL $PortalURL `
                        -WebserviceUrl $WebserviceUrl

$NewOutputFileFullPath = join-path $sourceDirPath $singleFileToChange
replaceTextSingleFileRegExArrayList $sourceDirPath $singleFileToChange $NewOutputFileFullPath $regExPatternArray $replaceStringArray  


#>


########################  SSL settings if they use SSL  ##################

# <authentication mode="Forms">
#       <forms name=".DOTNETNUKE" protection="All" timeout="60" cookieless="UseCookies" requireSSL="true" />
# </authentication>
# <httpCookies httpOnlyCookies="true" requireSSL="true" domain="" />
# <anonymousIdentification enabled="true" cookieName=".ASPXANONYMOUS" cookieTimeout="100000" cookiePath="/" cookieRequireSSL="true" cookieSlidingExpiration="true" cookieProtection="All" domain="" />






<#    
#--------------  Update the Link Database to point to CIS + Portal Alias  ----------

sp_change_users_login 'Auto_Fix', 'Advanced'
-- v3 only
select CISConnectionString, WEBSERVICEURL from eCAReManager
-- v3/4
select * from PortalAlias


# Install-Module sqlserver
# After the module has installed, the module commands including the Invoke-sqlcmd should be readily available.
# You can check the same using Get-Command -ModuleName sqlserver.
# If this module is not readily available, you can 


    # Import-Module sqlserver 

        # CIS  CIS  CIS  CIS  CIS DB info
        $CIS_Server = 'BPW33Z2'
        $CIS_DBName = 'UC2018v3'
        $CIS_User = 'ADVANCED'
        $CIS_Pwd = 'PATSINCOMMAND'
        $WEBSERVICEURL = 'http://pe3.local/aws_director/Director.asmx'
        $PortalAlias = 'ecaretest2.ci.richland.wa.us'

# Install-Module sqlserver

# check existing 
$query = 'select CISConnectionString, WEBSERVICEURL from eCAReManager'
Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd
write-host $query
$query = 'select * from PortalAlias'
Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd
write-host $query


$query = "update eCAReManager set CISConnectionString = 'Server={0};Database={1};uid={2};pwd={3};'" -f $CIS_Server ,$CIS_DBName,$CIS_User,$CIS_Pwd
Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd
write-host $query
$query = "update eCAReManager set WEBSERVICEURL= '{0}'" -f $WEBSERVICEURL
Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd
write-host $query
$query = "update PortalAlias set HTTPAlias = '{0}' where PortalID = 0" -f $PortalAlias
Invoke-Sqlcmd -Query $query -ServerInstance $Server -Database $DBName -Username $User -Password $Pwd
write-host $query

#>
