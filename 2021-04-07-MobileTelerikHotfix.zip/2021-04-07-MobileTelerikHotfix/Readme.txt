
also includes CVE-2019-18935 to add <add key="Telerik.Web.DisableAsyncUploadHandler" value="true"/> in <appSettings> tag:


**** make a backup of folers manually

install the urlrewrite2.exe


open the web.config file

•	Search for “maxRequestLenght” in the web.config file
•	Change the value from: 8192 to 18192 -- this will allow you to install the hotfix
upload Dnn_SecurityHotFix20171_NET35_01.02.00_Install.zip

SSL- change to True if they use it in the web.config

CheckBiography: Check if public profile fields use richtext
Login as host then goto AdminSite SettingsUser Account Settings tab Profile Settings section, and look in the grid for any DataType has “RichText” and change it to “Text”


--------- script -------------
 Change the following variables
$sourceDir = 'C:\inetpub\wwwroot\v3\InfinityMobile\InfinityMobile20Test\MobileDispatch\Dispatch'
$purgeLogDateOlderThan = '03/25/2021' #MM/DD/YYYY

Run script....
Doble check default pages... should only have default.aspx and Default.asp